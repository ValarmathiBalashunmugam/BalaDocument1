/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ns;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
 *
 * @author bramu
 */
public class LookupForm extends org.apache.struts.action.ActionForm {
    
 private String symbol = null;
    private Double stockprice = null;

    public String getSymbol() {

        return (symbol);
    }

    public void setSymbol(String symbol) {

        this.symbol = symbol;
    }

    public Double getStockprice() {
        return stockprice;
    }

    public void setStockprice(Double stockprice) {
        this.stockprice = stockprice;
    }

    public void reset(ActionMapping mapping,
            HttpServletRequest request) {

        this.symbol = null;
         this.stockprice= null;
    }
    /**
     *
     */
    public LookupForm() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * This is the action called from the Struts framework.
     *
     * @param mapping The ActionMapping used to select this instance.
     * @param request The HTTP Request we are processing.
     * @return
     */
    public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        if (getSymbol() == null || getSymbol().length() < 1) {
            errors.add("symbol", new ActionMessage("error.symbol.required"));
            // TODO: add 'error.name.required' key to your resources
        }
        return errors;
    }
}
