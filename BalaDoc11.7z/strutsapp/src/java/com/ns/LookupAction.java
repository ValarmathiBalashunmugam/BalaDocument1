/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ns;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

/**
 *
 * @author bramu
 */
public class LookupAction extends org.apache.struts.action.Action {

    /* forward name="success" path="" */
    private static final String SUCCESS = "success";
    private static final String FAILURE = "failure";

        
    private Double getQuote(String symbol) {

        if ( symbol.equalsIgnoreCase("LIC") ) {
          return 1250.00;
        }
        else if ( symbol.equalsIgnoreCase("ABC") ) {
          return 124.00;
        }
        else {
            return null;
        }
  }
    /**
     * This is the action called from the Struts framework.
     *
     * @param mapping The ActionMapping used to select this instance.
     * @param form The optional ActionForm bean for this request.
     * @param request The HTTP Request we are processing.
     * @param response The HTTP Response we are processing.
     * @throws java.lang.Exception
     * @return
     */
    
    @Override
    public ActionForward execute(ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response)
        throws IOException, ServletException {

    Double price = null;
    String symbol = null;
    LookupForm lookupForm=null;
    // Default target to success
    String target = SUCCESS;

    if ( form != null ) {

      lookupForm = (LookupForm)form;

      symbol = lookupForm.getSymbol();

      price = getQuote(symbol);
    }
    
	// if price is null, set the target to failure
    if ( price == null ) {
      target = FAILURE;
      
      ActionMessages errors = new ActionMessages();
            errors.add("symbol",
                    new ActionMessage("errors.incorrect.symbol", symbol));

            // Report any errors we have discovered
            if (!errors.isEmpty()) {
                saveErrors(request, errors);
            }
    }
    else {
     lookupForm.setStockprice(price);
    }
    // Forward to the appropriate View
    return (mapping.findForward(target));   
  }
}
