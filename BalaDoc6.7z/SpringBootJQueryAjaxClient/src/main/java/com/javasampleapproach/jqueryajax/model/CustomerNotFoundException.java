package com.javasampleapproach.jqueryajax.model;

public class CustomerNotFoundException extends RuntimeException {
	private String firstname;

	public CustomerNotFoundException(String firstname) {
		this.firstname = firstname;
	}
	
	public String getFirstname() {
		return firstname;
	}
}
