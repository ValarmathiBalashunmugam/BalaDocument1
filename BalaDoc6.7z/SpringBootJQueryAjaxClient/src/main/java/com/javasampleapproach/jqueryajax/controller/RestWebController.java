package com.javasampleapproach.jqueryajax.controller;

import java.util.ArrayList;

import org.springframework.http.HttpStatus;
import java.util.List;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.javasampleapproach.jqueryajax.message.Response;
import com.javasampleapproach.jqueryajax.model.Customer;
import com.javasampleapproach.jqueryajax.model.CustomerNotFoundException;
import com.javasampleapproach.jqueryajax.model.Error;

@RestController
public class RestWebController {

	List<Customer> cust = new ArrayList<Customer>();

	@RequestMapping(value = "/customers", method = RequestMethod.GET)
	public Response getResource() {
		Response response = new Response("Done", cust);
		return response;
	}

	@RequestMapping(value = "/customers", method = RequestMethod.POST)
	public Response postCustomer(@RequestBody Customer customer) {
		cust.add(customer);
		// Create Response Object
		Response response = new Response("Done", customer);
		return response;
	}
	

	@RequestMapping(value = "/customers/{firstname}", method = RequestMethod.GET)
	public Customer getCustomerByFirstname(@PathVariable String firstname) {	
		for(Customer customer:cust) {
			if(customer.getFirstname().equalsIgnoreCase(firstname)){
				return customer;
			}
		}		
		throw new CustomerNotFoundException(firstname);		
	}
	
	
	@ExceptionHandler(CustomerNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public Error customerNotFound(CustomerNotFoundException e) {
	  String firstname = e.getFirstname();
	  return new Error(1004, "Customer with firstname [" + firstname + "] not found");
	}
		
}