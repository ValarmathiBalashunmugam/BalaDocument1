package net.javaguides.springbootsecurity.web;

public class MessageNotFoundException extends RuntimeException {

		  private static final long serialVersionUID = 1L;
		  
		  private int messageId;

		  public MessageNotFoundException(int messageId) {
		    this.messageId = messageId;
		  }
		  
		  public MessageNotFoundException(String errorMessage, int id) {
			  super(errorMessage);
			  this.messageId = id;
		  }
		  
		  public int getMessageId() {
		    return messageId;
		  }
		  
		}

