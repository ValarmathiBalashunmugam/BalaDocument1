/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ns.springjavaconfigapp;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

/**
 *
 * @author bramu
 */
@Configuration
public class AppConfig {
    
    @Bean
    
    public IGreeting greeting() {
        return new Greeting();
    }
    
    @Bean
    @Scope("prototype")
    public Employee employee() {
        return new Employee();
    }
    
    @Bean
    public Department finance() {
        return new Department("D001", "Finance");
    }
    
    @Bean
    public Department production() {
        return new Department("D002", "Production");
    }
    
    @Bean
    public Employee mano() {
        return new Employee("E003", "Morris Mano", 75000.00f, production());
    }
}
